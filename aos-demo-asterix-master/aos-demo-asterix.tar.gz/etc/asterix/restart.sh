#!/bin/bash

# echo "hello" >> logfile.txt
sudo systemctl restart asterix